/* 
 * File:   delay.h
 * Author: m91511
 *
 * Created on July 14, 2015, 1:17 PM
 */

#ifndef DELAY_H
#define	DELAY_H

#ifdef	__cplusplus
extern "C" {
#endif

#define ON            1
#define OFF           0
#define NOT_JOINED    0
#define JOINED        1
#define GREEN_LED  LATAbits.LA6
#define RED_LED    LATAbits.LA7

void Delay (uint16_t ms);

void ConfigureBaudRate (void);

void ClearReceptionBuffer (void);

#ifdef	__cplusplus
}
#endif

#endif	/* DELAY_H */

